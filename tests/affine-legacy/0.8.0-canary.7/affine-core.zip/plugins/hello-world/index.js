({ imports: $h‍_imports, liveVar: $h‍_live, onceVar: $h‍_once, importMeta: $h‍____meta }) => {
  let rootStore, currentWorkspaceIdAtom, lazy, createElement, createRoot;
  $h‍_imports([["@toeverything/plugin-infra/atom", [["rootStore", [($h‍_a) => rootStore = $h‍_a]], ["currentWorkspaceIdAtom", [($h‍_a) => currentWorkspaceIdAtom = $h‍_a]]]], ["react", [["lazy", [($h‍_a) => lazy = $h‍_a]], ["createElement", [($h‍_a) => createElement = $h‍_a]]]], ["react-dom/client", [["createRoot", [($h‍_a) => createRoot = $h‍_a]]]]]);
  const HeaderItem = lazy(
    () => $h‍_import("./app-1e2823.mjs").then(({ HeaderItem: HeaderItem2 }) => ({ default: HeaderItem2 }))
  );
  const entry = (context) => {
    console.log("register");
    console.log("hello, world!");
    console.log(rootStore.get(currentWorkspaceIdAtom));
    context.register("headerItem", (div) => {
      const root = createRoot(div);
      root.render(createElement(HeaderItem));
      return () => {
        root.unmount();
      };
    });
    context.register("formatBar", (div) => {
      const root = createRoot(div);
      root.render(createElement(HeaderItem));
      return () => {
        root.unmount();
      };
    });
    return () => {
      console.log("unregister");
    };
  };
  $h‍_once.entry(entry);
};
