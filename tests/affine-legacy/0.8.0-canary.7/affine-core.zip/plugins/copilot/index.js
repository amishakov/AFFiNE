({ imports: $h‍_imports, liveVar: $h‍_live, onceVar: $h‍_once, importMeta: $h‍____meta }) => {
  $h‍_imports([["react", []], ["react-dom/client", []], ["./index-fd3681.mjs", []], ["react/jsx-runtime", []], ["@affine/component", []], ["jotai", []], ["jotai/utils", []], ["@blocksuite/icons", []], ["@toeverything/plugin-infra/atom", []]]);
};
